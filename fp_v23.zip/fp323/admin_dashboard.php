<?php
// Start session and check if the admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Database connection variables
$servername = "localhost";
$username = "root"; // replace with your database username
$password = ""; // replace with your database password
$dbname = "paw_finder"; // replace with your database name

// Create a new MySQLi connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch count of records
function fetchCount($conn, $query) {
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    return $row ? $row['count'] : 0;
}

// Fetch counts for dogs, cats, and other pets
$total_dogs = fetchCount($conn, "SELECT COUNT(*) AS count FROM dogs");
$total_cats = fetchCount($conn, "SELECT COUNT(*) AS count FROM cats");
$total_other_pets = fetchCount($conn, "SELECT COUNT(*) AS count FROM other_pets");

// Calculate the total pets by adding the counts of dogs, cats, and other pets
$total_pets = $total_dogs + $total_cats + $total_other_pets;

// Fetch the count of feedbacks and adoption requests before closing the connection
$total_feedbacks = fetchCount($conn, "SELECT COUNT(*) AS count FROM feedback");
$total_adoption_requests = fetchCount($conn, "SELECT COUNT(*) AS count FROM adoption_requests");

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            color: #333;
            display: flex;
            height: 100vh;
            flex-direction: column;
        }

        /* Navbar Styling */
        nav {
            background-color: #2c3e50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 1.1rem;
            margin-right: 20px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #f39c12;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
        }

        /* Sidebar Styling */
        .container {
            display: flex;
            flex: 1;
        }

        .sidebar {
            background-color: #34495e;
            color: #ecf0f1;
            width: 250px;
            padding-top: 20px;
            height: 100%;
            position: sticky;
            top: 0;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 1.2rem;
            padding: 15px 25px;
            display: block;
            margin: 8px 0;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #f39c12;
        }

        .sidebar a.active {
            background-color: #e67e22;
        }

        /* Main Content Styling */
        .main-content {
            flex: 1;
            padding: 30px;
            background-color: #ecf0f1;
        }

        h1 {
            color: #2c3e50;
        }

        .statistics {
            margin-top: 30px;
        }

        .statistics h3 {
            color: #2c3e50;
            margin-bottom: 20px;
        }

        .statistics .stat-item {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .statistics .stat-item h4 {
            font-size: 1.4rem;
            color: #f39c12;
            font-weight: bold;
        }

        .statistics .stat-item p {
            font-size: 1.2rem;
            color: #333;
        }

        .button {
            padding: 8px 16px;
            background-color: #f39c12;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #e67e22;
        }

        /* Footer Styling */
        .footer {
            background-color: #2c3e50;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                padding-top: 10px;
            }

            .sidebar a {
                font-size: 1rem;
                padding: 12px 20px;
            }

            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <div class="navbar-brand">Paw Finder Admin</div>
        <div>
            <a href="logout.php">Logout</a>
        </div>
    </nav>

    <!-- Main Content Section -->
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="admin_dashboard.php" class="active">Dashboard</a>
            <a href="update_dogs.php">Update Dogs</a>
            <a href="update_cats.php">Update Cats</a>
            <a href="update_other.php">Update Pets</a>
            <a href="view_dogs.php">View Dogs</a>
            <a href="view_cats.php">View Cats</a>
            <a href="view_other.php">View Pets</a>
            <a href="view_adoptionreq.php">View Adoption Requests</a>
            <a href="view_feedbacks.php">User Feedbacks</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>Welcome to the Admin Dashboard</h1>
            <p>Here you can manage pets, view adoption requests, and handle user feedback.</p>

            <div class="statistics">
                <h3>Statistics</h3>

                <!-- Total Pets -->
                <div class="stat-item">
                    <div>
                        <h4>Total Pets Available</h4>
                        <p><?php echo $total_pets; ?> Pets</p>
                    </div>
                </div>

                <!-- Total Dogs -->
                <div class="stat-item">
                    <div>
                        <h4>Total Dogs</h4>
                        <p><?php echo $total_dogs; ?> Dogs</p>
                    </div>
                </div>

                <!-- Total Cats -->
                <div class="stat-item">
                    <div>
                        <h4>Total Cats</h4>
                        <p><?php echo $total_cats; ?> Cats</p>
                    </div>
                </div>

                <!-- Total Other Pets -->
                <div class="stat-item">
                    <div>
                        <h4>Total Other Pets</h4>
                        <p><?php echo $total_other_pets; ?> Other Pets</p>
                    </div>
                </div>

                <!-- Total Feedbacks -->
                <div class="stat-item">
                    <div>
                        <h4>Total Feedbacks</h4>
                        <p><?php echo $total_feedbacks; ?> Feedbacks</p>
                    </div>
                </div>

                <!-- Total Adoption Requests -->
                <div class="stat-item">
                    <div>
                        <h4>Total Adoption Requests</h4>
                        <p><?php echo $total_adoption_requests; ?> Requests</p>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 Paw Finder. All Rights Reserved.</p>
    </div>

</body>
</html>
