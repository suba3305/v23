<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paw_finder";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete other pet if 'delete_id' is set in the URL
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare the DELETE SQL query
    $delete_sql = "DELETE FROM other_pets WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Other pet deleted successfully.";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch all other pets from the database
$sql = "SELECT * FROM other_pets";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View & Manage Other Pets</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background: #f7f7f7;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: flex-start;  /* Align the content at the top */
            flex-direction: column;
            height: 100%;
            margin: 0;
        }

        /* Navbar Styling */
        nav {
            background-color: #333;
            padding: 15px 0;
            width: 100%;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        nav a {
            color: #fff;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 600;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #f9a825;
        }

        .active {
            color: #f9a825;
            border-bottom: 3px solid #f9a825;
        }

        /* Main Container */
        .container {
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 1000px;
            margin-top: 40px;
        }

        .container h1 {
            text-align: center;
            font-size: 2.2rem;
            color: #333;
            margin-bottom: 20px;
        }

        /* Message Styling */
        .message {
            margin-top: 20px;
            padding: 15px;
            text-align: center;
            border-radius: 5px;
            background-color: #f9f9f9;
            color: #333;
            border: 1px solid #ddd;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Other Pets List Styling */
        .other-pet-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); /* Ensures the grid adjusts */
            gap: 30px;
            padding: 0;
            list-style-type: none;
            margin-top: 30px;
        }

        /* Individual Other Pet Card */
        .other-pet-item {
            background-color: #fff;
            border: 2px solid #ddd;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            padding: 20px;
        }

        .other-pet-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        .other-pet-item img {
            width: 100%;
            height: 250px; /* Increased height for better visibility */
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .other-pet-item .info {
            margin-bottom: 15px;
        }

        .other-pet-item .info strong {
            font-size: 1.2rem;
            color: #2a3d66;
            display: block;
            margin-bottom: 8px;
        }

        .other-pet-item .info em {
            font-size: 1rem;
            color: #555;
            margin-bottom: 10px;
        }

        .other-pet-item .info span {
            display: block;
            font-size: 1rem;
            margin-top: 5px;
            color: #444;
        }

        /* Action Buttons Styling */
        .action-buttons {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-top: 10px; /* Added margin to space the buttons from content */
        }

        .action-buttons a {
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
            width: 48%;
            text-align: center;
        }

        .edit-button {
            background-color: #f0ad4e;
            color: white;
        }

        .edit-button:hover {
            background-color: #ec971f;
        }

        .delete-button {
            background-color: #d9534f;
            color: white;
        }

        .delete-button:hover {
            background-color: #c9302c;
        }

    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <nav>
        <a href="index.php" class="logo">Paw Finder</a>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="view_dogs.php">Dogs</a>
        <a href="view_cats.php">Cats</a>
        <a href="view_other_pets.php" class="active">Other Pets</a>
    </nav>

    <!-- Main Content Container -->
    <div class="container">
        <h1>View & Manage Other Pets</h1>

        <?php if (isset($message)) { echo "<div class='message " . (strpos($message, 'success') !== false ? 'success' : 'error') . "'>$message</div>"; } ?>

        <ul class="other-pet-list">
            <?php if ($result->num_rows > 0) {
                while ($pet = $result->fetch_assoc()) { ?>
                    <li class="other-pet-item">
                        <img src="<?php echo htmlspecialchars($pet['image']); ?>" alt="Other Pet Image">
                        <div class="info">
                            <strong><?php echo htmlspecialchars($pet['name']); ?></strong>
                            <em><?php echo htmlspecialchars($pet['description']); ?></em>
                            <span>Price: ₹<?php echo htmlspecialchars($pet['price']); ?></span>
                        </div>
                        <div class="action-buttons">
                            <a href="edit_other_pet.php?id=<?php echo $pet['id']; ?>" class="edit-button">Edit</a>
                            <a href="?delete_id=<?php echo $pet['id']; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this pet?')">Delete</a>
                        </div>
                    </li>
                <?php }
            } else {
                echo "<li>No other pets found in the database.</li>";
            } ?>
        </ul>
    </div>

</body>
</html>
