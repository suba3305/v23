<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paw_finder";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete other pet if 'delete_id' is set in the URL
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare the DELETE SQL query
    $delete_sql = "DELETE FROM other_pets WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Other pet deleted successfully.";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch all other pets from the database
$sql = "SELECT * FROM other_pets";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View & Delete Other Pets</title>
    <style>
        /* Styling similar to the previous example */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(45deg, #f4f4f9, #dde1e7);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }

        .container {
            background: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        .container h1 {
            text-align: center;
            font-size: 2rem;
            color: #2a3d66;
            margin-bottom: 20px;
        }

        .other-pet-list {
            list-style-type: none;
            padding: 0;
        }

        .other-pet-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }

        .other-pet-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            margin-right: 20px;
        }

        .other-pet-item .info {
            flex-grow: 1;
        }

        .other-pet-item .delete-button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .other-pet-item .delete-button:hover {
            background-color: #c9302c;
        }

        .message {
            margin-top: 20px;
            padding: 15px;
            text-align: center;
            border-radius: 5px;
            background-color: #f9f9f9;
            color: #333;
            border: 1px solid #ddd;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>View & Delete Other Pets</h1>

        <?php if (isset($message)) { echo "<div class='message " . (strpos($message, 'success') !== false ? 'success' : 'error') . "'>$message</div>"; } ?>

        <ul class="other-pet-list">
            <?php if ($result->num_rows > 0) {
                while ($pet = $result->fetch_assoc()) { ?>
                    <li class="other-pet-item">
                        <img src="<?php echo htmlspecialchars($pet['image']); ?>" alt="Other Pet Image">
                        <div class="info">
                            <strong><?php echo htmlspecialchars($pet['name']); ?></strong><br>
                            <em><?php echo htmlspecialchars($pet['description']); ?></em><br>
                            <span>Price: ₹<?php echo htmlspecialchars($pet['price']); ?></span>
                        </div>
                        <a href="?delete_id=<?php echo $pet['id']; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this pet?')">Delete</a>
                    </li>
                <?php }
            } else {
                echo "<li>No other pets found in the database.</li>";
            } ?>
        </ul>
    </div>

</body>
</html>
