<?php
session_start();

// Check if the user is logged in and is a regular user
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header('Location: login.php'); // Redirect to login page if not logged in as user
    exit;
}

echo "<h1>Welcome, User!</h1>";
echo "<p>This is the user dashboard.</p>";
echo "<a href='login.php?logout=true'>Logout</a>";
?>
