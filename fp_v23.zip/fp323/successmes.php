<?php
session_start();

// Ensure the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Simulate successful payment submission (for demonstration)
$payment_success = false; // Set this to true if the payment is successful

// Check if form is submitted and payment is successful
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Here, you would typically process payment, but we'll simulate success for now.
    $payment_success = true; // Simulating success
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Success</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            color: #333;
            line-height: 1.6;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #ffffff; /* White background */
           
        }
        
        .container {
            position: relative;
            text-align: center;
        }

        .success-message {
            background-color: #28a745; /* Success color */
            color: white;
            border-radius: 12px;
            padding: 40px;
            max-width: 450px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1), 0 20px 40px rgba(0, 0, 0, 0.1); /* Enhanced shadow */
            opacity: 0;
            transform: translateY(-30px);
            transition: opacity 0.5s ease, transform 0.5s ease;
        }

        .success-message.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 999;
        }

        .overlay.visible {
            opacity: 1;
        }

        .icon {
            font-size: 60px;
            margin-bottom: 20px;
            animation: bounce 1s infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        h2 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }

        p {
            font-size: 1em;
        }
    </style>
</head>
<body>
    <div class="overlay" id="overlay"></div>
    <div class="container">
        <div class="success-message" id="success-message">
            <div class="icon"><i class="fas fa-check-circle"></i></div>
            <h2>Payment Successful!</h2>
            <p>Thank you for adopting a pet. Your transaction has been processed.</p>
        </div>
    </div>

    <script>
        // Show the success message after form submission
        <?php if ($payment_success): ?>
            window.onload = function() {
                const successMessage = document.getElementById('success-message');
                const overlay = document.getElementById('overlay');
                
                successMessage.classList.add('visible');
                overlay.classList.add('visible');

                // Optional: Close the message and overlay after 5 seconds
                setTimeout(function() {
                    successMessage.classList.remove('visible');
                    overlay.classList.remove('visible');
                }, 5000); // Hide after 5 seconds
            };
        <?php endif; ?>
    </script>
</body>
</html>