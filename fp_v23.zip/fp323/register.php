<?php
session_start();

// Handle user registration (one-time)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    // Get the username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the user already exists (we are storing users in a file)
    $users_file = 'users.txt';  // A file to store usernames and passwords
    $users = file($users_file, FILE_IGNORE_NEW_LINES);

    foreach ($users as $user) {
        list($stored_username, $stored_password) = explode(':', $user);
        if ($username == $stored_username) {
            $error_message = "Username already taken!";  // Show error if username exists
            break;
        }
    }

    if (!isset($error_message)) {
        // Save the new user to the file
        file_put_contents($users_file, "$username:$password\n", FILE_APPEND);
        $_SESSION['user_id'] = $username;  // Log the user in immediately
        header("Location: adopt_now.php");  // Redirect to the adoption page after registration
        exit;
    }
}

// Handle user login (sign-in)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    // Get the username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the user exists in the file
    $users_file = 'users.txt';
    $users = file($users_file, FILE_IGNORE_NEW_LINES);

    $valid_user = false;
    foreach ($users as $user) {
        list($stored_username, $stored_password) = explode(':', $user);
        if ($username == $stored_username && $password == $stored_password) {
            $valid_user = true;  // User found, credentials match
            break;
        }
    }

    if ($valid_user) {
        // Set session variable upon successful login
        $_SESSION['user_id'] = $username;
        header("Location: adopt_now.php");  // Redirect to the adoption page upon successful login
        exit;
    } else {
        $error_message = "Invalid username or password!";  // Show error if invalid login attempt
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register / Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            background: url(img/lg.webp) ;
            margin: 0;
            padding: 20px;
        }

        h2 {
            color: #333;
        }

        .container {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
        }

        button:hover {
            background-color: #4cae4c;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .sign-in-link {
            text-align: center;
            margin-top: 10px;
        }

        .sign-in-link a {
            color: #007bff;
            text-decoration: none;
        }

        .sign-in-link a:hover {
            text-decoration: underline;
        }

        .hide {
            display: none;
        }
    </style>
    <script>
        function showSignInForm() {
            // Hide the Register form and show the Sign In form
            document.getElementById("register-form").classList.add("hide");
            document.getElementById("login-form").classList.remove("hide");
        }

        function showRegisterForm() {
            // Hide the Sign In form and show the Register form
            document.getElementById("register-form").classList.remove("hide");
            document.getElementById("login-form").classList.add("hide");
        }
    </script>
</head>
<body>

    <div class="container" id="register-form">
        <h2>Register</h2>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
        
        <!-- Registration Form -->
        <form method="POST" action="register.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="register">Register</button>
        </form>

        <!-- Sign In Link for Already Registered Users -->
        <div class="sign-in-link">
            <p>Already registered? <a href="javascript:void(0);" onclick="showSignInForm()">Sign In</a></p>
        </div>
    </div>

    <div class="container hide" id="login-form">
        <h2>Sign In</h2>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
        
        <!-- Login Form -->
        <form method="POST" action="register.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="login">Sign In</button>
        </form>

        <!-- Back to Register Link -->
        <div class="sign-in-link">
            <p>Don't have an account? <a href="javascript:void(0);" onclick="showRegisterForm()">Register</a></p>
        </div>
    </div>

</body>
</html>
