<?php
session_start();

// Include database connection file
include('db.php');

// Ensure the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Sanitize input data for security
$pet_type = htmlspecialchars($_POST['pet_type'], ENT_QUOTES, 'UTF-8');
$pet_name = htmlspecialchars($_POST['pet_name'], ENT_QUOTES, 'UTF-8');
$pet_age = htmlspecialchars($_POST['pet_age'], ENT_QUOTES, 'UTF-8');
$full_name = htmlspecialchars($_POST['full_name'], ENT_QUOTES, 'UTF-8');
$email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
$phone = htmlspecialchars($_POST['phone'], ENT_QUOTES, 'UTF-8');
$address = htmlspecialchars($_POST['address'], ENT_QUOTES, 'UTF-8');
$reason = htmlspecialchars($_POST['reason'], ENT_QUOTES, 'UTF-8');

// Optionally, insert the data into the database (for example, saving adoption details)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Insert the details into the database
    $stmt = $pdo->prepare("INSERT INTO adoption_requests(pet_type, pet_name, pet_age, full_name, email, phone, address, reason)
                           VALUES (:pet_type, :pet_name, :pet_age, :full_name, :email, :phone, :address, :reason)");

    $stmt->bindParam(':pet_type', $pet_type);
    $stmt->bindParam(':pet_name', $pet_name);
    $stmt->bindParam(':pet_age', $pet_age);
    $stmt->bindParam(':full_name', $full_name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':reason', $reason);

    if ($stmt->execute()) {
        // Successfully inserted the adoption details
    } else {
        // Handle error here (e.g., notify the user that the submission failed)
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Adoption and Payment</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* Basic reset for margins and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9;
            background: url('img/login.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            line-height: 1.6;
        }

        /* Overlay for background */
        .overlay {
            position: relative;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5); /* Darker overlay */
        }

        /* Form container */
        .form-container {
            position: relative;
            width: 90%;
            max-width: 700px;
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.8); /* Glass effect */
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px); /* Glass effect */
            transition: all 0.3s ease;
        }

        .form-container h1 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #2d3e50;
        }

        /* Section styling */
        .section-title {
            font-size: 20px;
            margin-top: 20px;
            margin-bottom: 10px;
            color: #2d3e50;
        }

        /* Details display */
        .details p {
            margin-bottom: 10px;
        }

        .details strong {
            color: #2d3e50;
        }

        /* Input fields */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            border-color: #2d3e50;
            outline: none;
        }

        /* Button styling */
        .form-group button {
            padding: 14px;
            background-color: #2d3e50;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s;
        }

        .form-group button:hover {
            background-color: #a77628;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .form-container {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<!-- Confirmation and Payment Form -->
<div class="form-container">
    <h1>Confirm Your Adoption</h1>
    <p>Please review the details of your pet adoption and proceed with payment below.</p>

    <h3 class="section-title">Pet Details:</h3>
    <div class="details">
        <p><strong>Pet Type:</strong> <?php echo ucfirst($pet_type); ?></p>
        <p><strong>Pet Name:</strong> <?php echo $pet_name; ?></p>
        <p><strong>Pet Age:</strong> <?php echo ucfirst($pet_age); ?></p>
    </div>

    <h3 class="section-title">Your Details:</h3>
    <div class="details">
        <p><strong>Full Name:</strong> <?php echo $full_name; ?></p>
        <p><strong>Email:</strong> <?php echo $email; ?></p>
        <p><strong>Phone:</strong> <?php echo $phone; ?></p>
        <p><strong>Address:</strong> <?php echo $address; ?></p>
    </div>

    <h3 class="section-title">Payment Details:</h3>
    <form method="post" action="successmes.php">
        <div class="form-group">
            <label for="card_name">Cardholder Name</label>
            <input type="text" id="card_name" name="card_name" maxlength="25" required pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed.">
        </div>

        <div class="form-group">
            <label for="card_number">Card Number</label>
            <input type="text" id="card_number" name="card_number" pattern="\d{4} \d{4} \d{4} \d{4}" maxlength="19" required title="Card number should be 16 digits, divided into 4 groups of 4 digits each with spaces in between.">
        </div>

        <div class="form-group">
            <label for="expiry_date">Expiry Date (MM/YY)</label>
            <input type="text" id="expiry_date" name="expiry_date" maxlength="5" required title="Expiry date should be in MM/YY format. Valid years from 2020 to 2030.">
        </div>

        <div class="form-group">
            <label for="cvv">CVV</label>
            <input type="text" id="cvv" name="cvv" pattern="\d{3}" maxlength="3" required title="CVV should be 3 digits.">
        </div>

        <div class="form-group">
            <button type="submit">Submit Payment</button>
        </div>
    </form>
</div>

<script>
    // Format card number with spaces after every 4 digits
    document.getElementById('card_number').addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, ''); // Remove non-digit characters
        if (value.length <= 16) {
            value = value.replace(/(\d{4})(?=\d)/g, '$1 '); // Add space after every 4 digits
        }
        e.target.value = value;
    });

    // Automatically add slash in expiry date after month input
    document.getElementById('expiry_date').addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, ''); // Remove non-digit characters
        if (value.length > 2 && value.length <= 4) {
            e.target.value = value.slice(0, 2) + '/' + value.slice(2, 4); // Add slash after the month
        }
    });

    // Restrict year in expiry date to 2020-2030
    document.getElementById('expiry_date').addEventListener('blur', function(e) {
        const value = e.target.value.split('/');
        if (value.length === 2) {
            const month = parseInt(value[0]);
            const year = parseInt(value[1]);
            if (month < 1 || month > 12 || year < 20 || year > 30) {
                alert('Please enter a valid expiry date between 2020 and 2030.');
            }
        }
    });
</script>

</body>
</html>
