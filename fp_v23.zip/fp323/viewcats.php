<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paw_finder";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete cat if 'delete_id' is set in the URL
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare the DELETE SQL query
    $delete_sql = "DELETE FROM cats WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Cat deleted successfully.";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch all cats from the database
$sql = "SELECT * FROM cats";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View & Delete Cats</title>
    <style>
        /* Styling similar to the previous example */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(45deg, #f4f4f9, #dde1e7);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }

        .container {
            background: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        .container h1 {
            text-align: center;
            font-size: 2rem;
            color: #2a3d66;
            margin-bottom: 20px;
        }

        .cat-list {
            list-style-type: none;
            padding: 0;
        }

        .cat-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }

        .cat-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            margin-right: 20px;
        }

        .cat-item .info {
            flex-grow: 1;
        }

        .cat-item .delete-button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .cat-item .delete-button:hover {
            background-color: #c9302c;
        }

        .message {
            margin-top: 20px;
            padding: 15px;
            text-align: center;
            border-radius: 5px;
            background-color: #f9f9f9;
            color: #333;
            border: 1px solid #ddd;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>View & Delete Cats</h1>

        <?php if (isset($message)) { echo "<div class='message " . (strpos($message, 'success') !== false ? 'success' : 'error') . "'>$message</div>"; } ?>

        <ul class="cat-list">
            <?php if ($result->num_rows > 0) {
                while ($cat = $result->fetch_assoc()) { ?>
                    <li class="cat-item">
                        <img src="<?php echo htmlspecialchars($cat['image']); ?>" alt="Cat Image">
                        <div class="info">
                            <strong><?php echo htmlspecialchars($cat['name']); ?></strong><br>
                            <em><?php echo htmlspecialchars($cat['description']); ?></em><br>
                            <span>Kitten Price: ₹<?php echo htmlspecialchars($cat['kitten_price']); ?></span><br>
                            <span>Adult Price: ₹<?php echo htmlspecialchars($cat['adult_price']); ?></span><br>
                            <span>Senior Price: ₹<?php echo htmlspecialchars($cat['senior_price']); ?></span>
                        </div>
                        <a href="?delete_id=<?php echo $cat['id']; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this cat?')">Delete</a>
                    </li>
                <?php }
            } else {
                echo "<li>No cats found in the database.</li>";
            } ?>
        </ul>
    </div>

</body>
</html>
