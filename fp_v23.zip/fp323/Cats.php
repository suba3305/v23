<?php
// Include the database connection file
include('db.php'); // Assuming db.php is in the same directory

// SQL query to fetch all cats from the database
$sql = "SELECT * FROM cats";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Adoption</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Navigation Styling */
        nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #a77628;
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .cat-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            padding: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .cat-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
        }

        .cat-card h2 {
            margin: 10px 0;
            color: #555;
        }

        .cat-card p {
            color: #777;
            padding: 0 15px;
        }

        /* Hover effect for scaling and shadow */
        .cat-card:hover {
            transform: scale(1.05); /* Scale up slightly */
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2); /* Larger shadow */
        }

        .age-dropdown {
            background-color: #2d3e50;
            color: white;
            padding: 12px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 16px;
            width: 100%;
            text-align: center;
            border: 1px solid #555;
        }

        .age-dropdown:hover {
            background-color: #f39c12;
            transform: scale(1.05); /* Slight zoom effect on hover */
        }

        .adopt-button {
            background-color: rgb(8, 5, 2);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 15px;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        .adopt-button:hover {
            background-color: rgb(230, 114, 6);
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <!-- Logo -->
        <a href="index.php" class="logo">Paw Finder</a>

        <!-- Dropdown Menu for Pets List -->
        <div class="dropdown">
            <a href="#">Pets List</a>
            <div class="dropdown-content">
                <a href="dogs.php">Dogs</a>
                <a href="cats.php">Cats</a>
                <a href="other_pets.php">Other Pets</a>
            </div>
        </div>

        <!-- Other Navigation Links -->
        <a href="pet_tips.php">Pet Tips</a>
   
        <a href="adopt_now.php">Adopt Now</a>
        <a href="pet_care.php">Pet Care</a>
        <a href="feedback.php">Feedback</a>
        <a href="login.php">Login</a>
        <a href="admin_login.php">Admin</a>
    </nav>

    <div class="container">
        <h1>Adopt a Cat Today!</h1>
        <div class="grid">
            <?php
            // Check if there are results
            if ($result->num_rows > 0) {
                // Output data for each cat
                while($row = $result->fetch_assoc()) {
                    echo '<div class="cat-card">';
                    echo '<img src="' . $row['image'] . '" alt="' . $row['name'] . '">';
                    echo '<h2>' . $row['name'] . '</h2>';
                    
                    // Dropdown for selecting cat age and price
                    echo '<select class="age-dropdown">';
                    echo '<option value="Kitten">Kitten - ₹' . $row['kitten_price'] . '</option>';
                    echo '<option value="Adult">Adult - ₹' . $row['adult_price'] . '</option>';
                    echo '<option value="Senior">Senior - ₹' . $row['senior_price'] . '</option>';
                    echo '</select>';

                    echo '<p>' . $row['description'] . '</p>';
                    echo '<a href="login.php"><button class="adopt-button">Adopt Now</button></a>';
                    echo '</div>';
                }
            } else {
                echo "No cats available.";
            }

            // Close the database connection
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
