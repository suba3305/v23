<?php
session_start();
include('db.php'); // Assuming db_connection.php contains the DB connection code

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}

// Fetch available pet types from the database
$query = "SELECT * FROM pet_types";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $pet_types = [];
    while ($row = $result->fetch_assoc()) {
        $pet_types[] = $row['type'];  // Assuming column name is 'type' in pet_types table
    }
} else {
    $pet_types = [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate form data
    $pet_type = $_POST['pet_type'];
    $pet_name = $_POST['pet_name'];
    $pet_age = $_POST['pet_age'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $reason = $_POST['reason'];

    // Validate email and phone
    if (filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($phone) === 10) {
        // Insert the adoption request into the database
        $stmt = $conn->prepare("INSERT INTO adoption_requests (pet_type, pet_name, pet_age, full_name, email, phone, address, reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $pet_type, $pet_name, $pet_age, $full_name, $email, $phone, $address, $reason);

        if ($stmt->execute()) {
            echo "Adoption request submitted successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Invalid email or phone number.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}

// Sample pet data (for demonstration purposes) - This should ideally be fetched from the database
$pets = [
    "dog" => [
        "Golden Retriever" => [
            "image" => "img/gr.jpg",
            "description" => "Friendly, reliable, and trustworthy.",
            "ages" => [
                "puppy" => 500,  // Price for puppy
                "adult" => 350,  // Price for adult
                "senior" => 200  // Price for senior
            ]
        ],
        "Bulldog" => [
            "image" => "img/bulldog.jpg",
            "description" => "Courageous, calm, and friendly.",
            "ages" => [
                "puppy" => 600,
                "adult" => 400,
                "senior" => 250
            ]
        ],
        // Additional dog breeds (up to 9)
        "Labrador" => [
            "image" => "img/labrador.jpg",
            "description" => "Friendly and outgoing.",
            "ages" => [
                "puppy" => 450,
                "adult" => 300,
                "senior" => 180
            ]
        ],
        "Beagle" => [
            "image" => "img/beagle.jpg",
            "description" => "Curious, friendly, and merry.",
            "ages" => [
                "puppy" => 400,
                "adult" => 280,
                "senior" => 150
            ]
        ],
        "German Shepherd" => [
            "image" => "img/german_shepherd.jpg",
            "description" => "Confident, courageous, and smart.",
            "ages" => [
                "puppy" => 700,
                "adult" => 500,
                "senior" => 300
            ]
        ],
        "Poodle" => [
            "image" => "img/poodle.jpg",
            "description" => "Intelligent, elegant, and active.",
            "ages" => [
                "puppy" => 650,
                "adult" => 450,
                "senior" => 280
            ]
        ],
        "Rottweiler" => [
            "image" => "img/rottweiler.jpg",
            "description" => "Loyal, fearless, and confident.",
            "ages" => [
                "puppy" => 750,
                "adult" => 550,
                "senior" => 350
            ]
        ],
        "Chihuahua" => [
            "image" => "img/chihuahua.jpg",
            "description" => "Lively, brave, and confident.",
            "ages" => [
                "puppy" => 400,
                "adult" => 250,
                "senior" => 150
            ]
        ],
        "Dachshund" => [
            "image" => "img/dachshund.jpg",
            "description" => "Curious, courageous, and clever.",
            "ages" => [
                "puppy" => 500,
                "adult" => 350,
                "senior" => 200
            ]
        ]
    ],
    "cat" => [
        "Persian Cat" => [
            "image" => "img/pc.jpg",
            "description" => "Gentle, affectionate, and calm.",
            "ages" => [
                "kitten" => 300,  // Price for kitten
                "adult" => 200,   // Price for adult
                "senior" => 100   // Price for senior
            ]
        ],
        "Siamese Cat" => [
            "image" => "img/ss.webp",
            "description" => "Social, talkative, and playful.",
            "ages" => [
                "kitten" => 350,
                "adult" => 250,
                "senior" => 150
            ]
        ],
        "Maine Coon" => [
            "image" => "img/maine_coon.jpg",
            "description" => "Large, friendly, and affectionate.",
            "ages" => [
                "kitten" => 400,
                "adult" => 300,
                "senior" => 180
            ]
        ],
        "British Shorthair" => [
            "image" => "img/british_shorthair.jpg",
            "description" => "Calm, affectionate, and independent.",
            "ages" => [
                "kitten" => 450,
                "adult" => 350,
                "senior" => 220
            ]
        ],
        "Ragdoll" => [
            "image" => "img/ragdoll.jpg",
            "description" => "Gentle, affectionate, and relaxed.",
            "ages" => [
                "kitten" => 500,
                "adult" => 400,
                "senior" => 250
            ]
        ],
        "Bengal Cat" => [
            "image" => "img/bengal_cat.jpg",
            "description" => "Energetic, affectionate, and intelligent.",
            "ages" => [
                "kitten" => 550,
                "adult" => 450,
                "senior" => 300
            ]
        ]
    ],
    "other" => [
        "Rabbit" => [
            "image" => "img/rabbit.jpg",
            "description" => "Gentle and social.",
            "price" => 100  // Fixed price for rabbit
        ],
        "Hamster" => [
            "image" => "img/hamster.jpg",
            "description" => "Cute and easy to care for.",
            "price" => 50
        ],
        "Guinea Pig" => [
            "image" => "img/guinea_pig.jpg",
            "description" => "Friendly and social.",
            "price" => 80
        ],
        "Turtle" => [
            "image" => "img/turtle.jpg",
            "description" => "Calm and low maintenance.",
            "price" => 30
        ],
        "Parrot" => [
            "image" => "img/parrot.jpg",
            "description" => "Colorful and social.",
            "price" => 120
        ],
        "Fish" => [
            "image" => "img/fish.jpg",
            "description" => "Easy to care for and peaceful.",
            "price" => 20
        ]
    ]
];


// Function to convert USD to INR (Indian Rupees)
function convertToINR($usd) {
    $conversion_rate = 80; // 1 USD = 80 INR
    return $usd * $conversion_rate;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adopt a Pet</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* Global Styles */
        body {
            font-family: 'Poppins', sans-serif;
            background: url('img/lg3.webp') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #333;
        }

        /* Overlay for background */
        .overlay {
            position: relative;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5); /* Darker overlay */
        }

        /* Container */
        .form-container {
            position: relative;
            width: 90%;
            max-width: 700px;
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.8); /* Glass effect */
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px); /* Glass effect */
            transition: all 0.3s ease;
        }

        .form-container:hover {
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-size: 28px;
            text-align: center;
            color: #2d3e50;
            margin-bottom: 20px;
        }

        p {
            font-size: 16px;
            color: #777;
            text-align: center;
            margin-bottom: 30px;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: #555;
            margin-bottom: 8px;
        }

        .form-group select, .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 16px;
            background-color: #f9f9f9;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        .form-group select:focus, .form-group input:focus, .form-group textarea:focus {
            border-color: rgb(230, 114, 6);
            outline: none;
        }

        .form-group textarea {
            resize: vertical;
        }

        .form-group button {
            width: 100%;
            padding: 15px;
            background-color: rgb(2, 5, 17);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .form-group button:hover {
            background-color: rgb(230, 114, 6);
        }

        .required {
            color: red;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h1>Adopt a Pet</h1>
    <form method="post" action="confirm_adoption.php" onsubmit="return validateForm()">
    <form method="post" action="" onsubmit="return validateForm()">
        <div class="form-group">
            <label for="pet_type">Preferred Pet Type <span class="required">*</span></label>
            <select id="pet_type" name="pet_type" required onchange="updatePetOptions()">
                <option value="">Select Pet Type</option>
                <?php foreach ($pet_types as $type) { ?>
                    <option value="<?php echo $type; ?>"><?php echo ucfirst($type); ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label for="pet_name">Select Pet <span class="required">*</span></label>
            <select id="pet_name" name="pet_name" required onchange="updatePetDetails()">
                <option value="">Select Pet</option>
                <!-- Options will be populated based on pet type selection -->
            </select>
        </div>

        <div class="form-group" id="pet_age_group" style="display: none;">
            <label for="pet_age">Select Pet Age <span class="required">*</span></label>
            <select id="pet_age" name="pet_age" required>
                <option value="">Select Age</option>
                <!-- Options will be populated based on selected pet -->
            </select>
        </div>

        <div class="form-group" id="pet_price" style="display: none;">
            <label for="price">Price <span class="required">*</span></label>
            <input type="text" id="price" name="price" readonly>
        </div>

        <div class="form-group">
            <label for="full_name">Full Name <span class="required">*</span></label>
            <input type="text" id="full_name" name="full_name" required maxlength="50">
        </div>

        <div class="form-group">
            <label for="email">Email Address <span class="required">*</span></label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="phone">Phone Number <span class="required">*</span></label>
            <input type="text" id="phone" name="phone" required maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>

        <div class="form-group">
            <label for="address">Home Address <span class="required">*</span></label>
            <input type="text" id="address" name="address" required>
        </div>

        <div class="form-group">
            <label for="reason">Why do you want to adopt? <span class="required">*</span></label>
            <textarea id="reason" name="reason" required rows="4" placeholder="Please explain why you want to adopt a pet."></textarea>
        </div>

        <!-- Other form fields go here -->

        <div class="form-group">
            <button type="submit">Submit Adoption Request</button>
        </div>
    </form>
</div>

<script>
// JavaScript functions to dynamically update pet options based on selection
function updatePetOptions() {
    var petType = document.getElementById("pet_type").value;
    var petNameSelect = document.getElementById("pet_name");
    var petAgeGroup = document.getElementById("pet_age_group");
    var petAgeSelect = document.getElementById("pet_age");
    var petPrice = document.getElementById("pet_price");
    var priceInput = document.getElementById("price");

    // Clear existing options
    petNameSelect.innerHTML = "<option value=''>Select Pet</option>";
    petAgeSelect.innerHTML = "<option value=''>Select Age</option>";
    petPrice.style.display = "none";
    petAgeGroup.style.display = "none";

    if (petType) {
        var pets = <?php echo json_encode($pets); ?>;
        var selectedPets = pets[petType];

        // Loop through selected pets and populate the pet name dropdown
        for (var pet in selectedPets) {
            var option = document.createElement("option");
            option.value = pet;
            option.text = pet;
            petNameSelect.appendChild(option);
        }
    }
}

function updatePetDetails() {
    var petType = document.getElementById("pet_type").value;
    var petName = document.getElementById("pet_name").value;
    var petAgeSelect = document.getElementById("pet_age");
    var petAgeGroup = document.getElementById("pet_age_group");
    var petPrice = document.getElementById("pet_price");
    var priceInput = document.getElementById("price");

    if (petName) {
        var pets = <?php echo json_encode($pets); ?>;
        var selectedPet = pets[petType][petName];

        if (selectedPet.ages) {
            petAgeGroup.style.display = "block";
            petPrice.style.display = "none";
            petAgeSelect.innerHTML = "<option value=''>Select Age</option>";

            for (var age in selectedPet.ages) {
                var option = document.createElement("option");
                option.value = age;
                option.text = age.charAt(0).toUpperCase() + age.slice(1) + " - Price: ₹" + convertToINR(selectedPet.ages[age]);
                petAgeSelect.appendChild(option);
            }
        } else {
            petAgeGroup.style.display = "none";
            petPrice.style.display = "block";
            priceInput.value = "₹" + convertToINR(selectedPet.price);
        }
    }
}

function convertToINR(usd) {
    var conversionRate = 80; // 1 USD = 80 INR
    return (usd * conversionRate).toFixed(2);
}
</script>

</body>
</html>
