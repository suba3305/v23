<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";  // replace with your database username
$password = "";      // replace with your database password
$dbname = "paw_finder";  // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle user registration (one-time)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username already exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error_message = "Username already taken!";
    } else {
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Save the new user to the database
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hashed_password);
        $stmt->execute();

        $_SESSION['user_id'] = $username;  // Log the user in immediately
        header("Location: adopt_now.php");  // Redirect to the adoption page after registration
        exit;
    }
}

// Handle user login (sign-in)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify the password with the hashed password stored in the database
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $username;  // Set session variable upon successful login
            header("Location: adopt_now.php");  // Redirect to the adoption page upon successful login
            exit;
        } else {
            $error_message = "Invalid username or password!";
        }
    } else {
        $error_message = "Invalid username or password!";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register / Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: url('img/h2.jpeg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background: rgba(255, 255, 255, 0.3); /* Semi-transparent background for the form */
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px); /* Glass effect */
            overflow: hidden;
        }

        h2 {
            text-align: center;
            color: #fff;
            font-size: 28px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #fff;
            font-size: 14px;
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            background-color: rgba(255, 255, 255, 0.8); /* Light background inside the input */
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            border-color: #5cb85c;
            outline: none;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(12, 10, 8);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: rgb(224, 122, 6);
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .sign-in-link, .sign-up-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }

        .sign-in-link a, .sign-up-link a {
            color: rgb(13, 14, 15);
            text-decoration: none;
        }

        .sign-in-link a:hover, .sign-up-link a:hover {
            text-decoration: underline;
        }

        .hide {
            display: none;
        }

        .footer {
            position: absolute;
            bottom: 10px;
            width: 100%;
            text-align: center;
            color: #aaa;
            font-size: 12px;
        }
    </style>
    <script>
        function showSignInForm() {
            document.getElementById("register-form").classList.add("hide");
            document.getElementById("login-form").classList.remove("hide");
        }

        function showRegisterForm() {
            document.getElementById("register-form").classList.remove("hide");
            document.getElementById("login-form").classList.add("hide");
        }
    </script>
</head>
<body>

    <div class="container" id="register-form">
        <h2>Register</h2>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="register">Register</button>
        </form>

        <div class="sign-in-link">
            <p>Already registered? <a href="javascript:void(0);" onclick="showSignInForm()">Sign In</a></p>
        </div>
    </div>

    <div class="container hide" id="login-form">
        <h2>Sign In</h2>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="login">Sign In</button>
        </form>

        <div class="sign-up-link">
            <p>Don't have an account? <a href="javascript:void(0);" onclick="showRegisterForm()">Register</a></p>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 Your Website | All rights reserved</p>
    </div>

</body>
</html>
