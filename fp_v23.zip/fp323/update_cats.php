<?php
// Include the database connection file
include('db.php');

// Initialize variables
$name = $image = $description = $kitten_price = $adult_price = $senior_price = "";
$error_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the form
    $name = $_POST['name'];
    $image = $_POST['image'];
    $description = $_POST['description'];
    $kitten_price = $_POST['kitten_price'];
    $adult_price = $_POST['adult_price'];
    $senior_price = $_POST['senior_price'];

    // Check for any empty fields
    if (empty($name) || empty($image) || empty($description) || empty($kitten_price) || empty($adult_price) || empty($senior_price)) {
        $error_message = "All fields are required!";
    } else {
        // If it's an add (not an update), insert into the database
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            // Updating existing cat (Edit Mode)
            $id = $_GET['id'];
            $sql = "UPDATE cats SET name=?, image=?, description=?, kitten_price=?, adult_price=?, senior_price=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssiiii", $name, $image, $description, $kitten_price, $adult_price, $senior_price, $id);
        } else {
            // Inserting new cat
            $sql = "INSERT INTO cats (name, image, description, kitten_price, adult_price, senior_price) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssiii", $name, $image, $description, $kitten_price, $adult_price, $senior_price);
        }

        if ($stmt->execute()) {
            // Redirect to the cats page after success
            header("Location: cats.php");
            exit;
        } else {
            $error_message = "Error saving the cat information.";
        }
    }
}

// If we're editing an existing cat, fetch its data
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM cats WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $cat = $result->fetch_assoc();
        $name = $cat['name'];
        $image = $cat['image'];
        $description = $cat['description'];
        $kitten_price = $cat['kitten_price'];
        $adult_price = $cat['adult_price'];
        $senior_price = $cat['senior_price'];
    } else {
        $error_message = "Cat not found.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Cat Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #a77628;
        }

        .container {
            width: 50%;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(14, 12, 12, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        input, textarea, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #2d3e50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a77628;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <nav>
        <a href="index.php" class="logo">Paw Finder</a>
        <a href="admin_dashboard.php" class="active">Dashboard</a>
        <a href="cats.php">Back to Cats</a>
    </nav>

    <div class="container">
        <h1><?php echo isset($cat) ? "Update Cat" : "Add New Cat"; ?></h1>
        
        <!-- Display error message if any -->
        <?php if ($error_message != ""): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
            
            <label for="image">Image URL:</label>
            <input type="text" id="image" name="image" value="<?php echo htmlspecialchars($image); ?>" required>
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($description); ?></textarea>
            
            <label for="kitten_price">Kitten Price (₹):</label>
            <input type="number" id="kitten_price" name="kitten_price" value="<?php echo htmlspecialchars($kitten_price); ?>" required>
            
            <label for="adult_price">Adult Price (₹):</label>
            <input type="number" id="adult_price" name="adult_price" value="<?php echo htmlspecialchars($adult_price); ?>" required>
            
            <label for="senior_price">Senior Price (₹):</label>
            <input type="number" id="senior_price" name="senior_price" value="<?php echo htmlspecialchars($senior_price); ?>" required>
            
            <button type="submit"><?php echo isset($cat) ? "Update Cat" : "Add Cat"; ?></button>
        </form>
    </div>

</body>
</html>
