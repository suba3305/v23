<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paw_finder";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'id' is set in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the dog details from the database
    $sql = "SELECT * FROM dogs WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);  // "i" for integer parameter
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the dog is found in the database
    if ($result->num_rows > 0) {
        $dog = $result->fetch_assoc();

        // Handle form submission for updating dog info
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get and sanitize the form data
            $name = htmlspecialchars($_POST['name']);
            $image = htmlspecialchars($_POST['image']);
            $description = htmlspecialchars($_POST['description']);
            $puppy_price = $_POST['puppy_price'];
            $adult_price = $_POST['adult_price'];
            $senior_price = $_POST['senior_price'];

            // Prepare the UPDATE SQL query
            $update_sql = "UPDATE dogs SET name=?, image=?, description=?, puppy_price=?, adult_price=?, senior_price=? WHERE id=?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("sssiiii", $name, $image, $description, $puppy_price, $adult_price, $senior_price, $id);

            if ($stmt->execute()) {
                $message = "Record updated successfully.";
            } else {
                $message = "Error: " . $stmt->error;
            }
        }
    } else {
        // If the dog ID doesn't exist in the database
        $message = "No dog found with the specified ID.";
    }

    $stmt->close();
} else {
    $message = "No dog ID specified.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dog Details</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(45deg, #f4f4f9, #dde1e7);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Container Styling */
        .container {
            background: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            transition: transform 0.3s ease-in-out;
        }

        .container:hover {
            transform: scale(1.02);
        }

        /* Title Styling */
        h1 {
            text-align: center;
            font-size: 2rem;
            color: #2a3d66;
            margin-bottom: 20px;
        }

        /* Form Label Styling */
        label {
            font-size: 1rem;
            color: #555;
            margin-bottom: 8px;
            display: block;
        }

        /* Input and Textarea Styling */
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            background-color: #fafafa;
            transition: border-color 0.3s ease, background-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="number"]:focus, textarea:focus {
            border-color: #007BFF;
            background-color: #e9f1ff;
        }

        /* Submit Button Styling */
        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            font-size: 1.1rem;
            padding: 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* Message Styling */
        .message {
            margin-top: 20px;
            padding: 15px;
            text-align: center;
            border-radius: 5px;
            background-color: #f9f9f9;
            color: #333;
            border: 1px solid #ddd;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .container {
                width: 90%;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Edit Dog Details</h1>
        <?php if (isset($message)) { echo "<div class='message " . (strpos($message, 'success') !== false ? 'success' : 'error') . "'>$message</div>"; } ?>

        <!-- Admin form to edit dog details -->
        <form method="POST">
            <label for="name">Dog Name:</label>
            <input type="text" name="name" value="<?php echo isset($dog) ? htmlspecialchars($dog['name']) : ''; ?>" required><br>

            <label for="image">Image URL:</label>
            <input type="text" name="image" value="<?php echo isset($dog) ? htmlspecialchars($dog['image']) : ''; ?>" required><br>

            <label for="description">Description:</label>
            <textarea name="description" required><?php echo isset($dog) ? htmlspecialchars($dog['description']) : ''; ?></textarea><br>

            <label for="puppy_price">Puppy Price:</label>
            <input type="number" name="puppy_price" value="<?php echo isset($dog) ? htmlspecialchars($dog['puppy_price']) : ''; ?>" required><br>

            <label for="adult_price">Adult Price:</label>
            <input type="number" name="adult_price" value="<?php echo isset($dog) ? htmlspecialchars($dog['adult_price']) : ''; ?>" required><br>

            <label for="senior_price">Senior Price:</label>
            <input type="number" name="senior_price" value="<?php echo isset($dog) ? htmlspecialchars($dog['senior_price']) : ''; ?>" required><br>

            <input type="submit" value="Update Dog Details">
        </form>
    </div>

</body>
</html>
