<?php
// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Database connection
include('db.php');  // Use the shared db connection file

// Fetch feedbacks from the database
$feedback_sql = "SELECT * FROM feedback";  // Replace 'feedback' with your actual table name
$feedback_result = $conn->query($feedback_sql);

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Feedbacks</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            color: #333;
            display: flex;
            height: 100vh;
            flex-direction: column;
        }

        /* Navbar Styling */
        nav {
            background-color: #2c3e50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 1.1rem;
            margin-right: 20px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #f39c12;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
        }

        /* Sidebar Styling */
        .container {
            display: flex;
            flex: 1;
        }

        .sidebar {
            background-color: #34495e;
            color: #ecf0f1;
            width: 250px;
            padding-top: 20px;
            height: 100%;
            position: sticky;
            top: 0;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 1.2rem;
            padding: 15px 25px;
            display: block;
            margin: 8px 0;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #f39c12;
        }

        .sidebar a.active {
            background-color: #e67e22;
        }

        /* Main Content Styling */
        .main-content {
            flex: 1;
            padding: 30px;
            background-color: #ecf0f1;
        }

        h1 {
            color: #2c3e50;
        }

        .statistics p {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f39c12;
            color: white;
        }

        td {
            background-color: #fff;
        }

        .button {
            padding: 8px 16px;
            background-color: #f39c12;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #e67e22;
        }

        /* Footer Styling */
        .footer {
            background-color: #2c3e50;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                padding-top: 10px;
            }

            .sidebar a {
                font-size: 1rem;
                padding: 12px 20px;
            }

            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <div class="navbar-brand">Paw Finder Admin</div>
        <div>
            <a href="logout.php">Logout</a>
        </div>
    </nav>

    <!-- Main Content Section -->
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="update_dogs.php">Update Dogs</a>
            <a href="update_cats.php">Update Cats</a>
            <a href="update_other.php">Update Pets</a>
            <a href="view_dogs.php">View Dogs</a>
            <a href="view_cats.php">View Cats</a>
            <a href="view_other.php">View Pets</a>
            <a href="view_adoptionreq.php">View Adoption Requests</a>
            <a href="view_feedbacks.php" class="active">User Feedbacks</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>User Feedbacks</h1>
            <p>Below are the feedbacks submitted by users.</p>

            <!-- Feedback Table -->
            <?php if ($feedback_result && $feedback_result->num_rows > 0) { ?>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Feedback Message</th>
                        <th>Submitted At</th>
                    </tr>
                    <?php while ($feedback = $feedback_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($feedback['id']); ?></td>
                            <td><?php echo htmlspecialchars($feedback['name']); ?></td>
                            <td><?php echo htmlspecialchars($feedback['email']); ?></td>
                            <td><?php echo htmlspecialchars($feedback['message']); ?></td>
                            <td><?php echo htmlspecialchars($feedback['submitted_at']); ?></td>
                        </tr>
                    <?php } ?>
                </table>
            <?php } else { ?>
                <p>No feedbacks found.</p>
            <?php } ?>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 Paw Finder. All Rights Reserved.</p>
    </div>

</body>
</html>
