<?php
session_start();

// Define admin credentials
define('ADMIN_USERNAME', 'suba3305');
define('ADMIN_PASSWORD', 'rajisuba33'); // Change this to your desired admin password

// Handle admin login (sign-in)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    // Get the username and password from the form and sanitize them
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Check if the provided credentials match the admin credentials
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        // Set session variable upon successful login
        $_SESSION['admin_id'] = $username;
        header("Location: admin_dashboard.php");  // Redirect to the admin dashboard after successful login
        exit;
    } else {
        $error_message = "Invalid username or password!";  // Show error if invalid login attempt
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: url('img/h2.jpeg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background: rgba(255, 255, 255, 0.3); /* Semi-transparent background for the form */
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px); /* Glass effect */
            overflow: hidden;
        }

        h2 {
            text-align: center;
            color: #fff;
            font-size: 28px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #fff;
            font-size: 14px;
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            background-color: rgba(255, 255, 255, 0.8); /* Light background inside the input */
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            border-color: #5cb85c;
            outline: none;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color:rgb(12, 10, 8);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color:rgb(224, 122, 6);
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .footer {
            position: absolute;
            bottom: 10px;
            width: 100%;
            text-align: center;
            color: #aaa;
            font-size: 12px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Admin Login</h2>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>

        <form method="POST" action="admin_login.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>
    </div>

    <div class="footer">
        <p>&copy; 2025 Your Website | All rights reserved</p>
    </div>

</body>
</html>
