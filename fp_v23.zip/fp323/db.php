<?php
// db.php - This will contain the database connection details

$servername = "localhost";  // Your server name, usually 'localhost'
$username = "root";         // Your MySQL username (usually 'root' for local)
$password = "";             // Your MySQL password (leave empty if none)
$dbname = "paw_finder";     // The name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
