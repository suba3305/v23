<?php
// Start the session
session_start();

// Sample users (username => password) with roles (admin or user)
$users = [
    'admin' => ['password' => 'adminpass', 'role' => 'admin'],
    'user' => ['password' => 'userpass', 'role' => 'user']
];

// Initialize error message variable
$error_message = '';

// Handle form submission when the user logs in
if (isset($_POST['login'])) {
    // Get the entered username and password
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username exists in the $users array
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        // If valid, set session variables
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $users[$username]['role'];

        // Redirect based on the user's role
        if ($_SESSION['role'] == 'admin') {
            header('Location: admin_dashboard.php');
            exit;
        } else {
            header('Location: user_dashboard.php');
            exit;
        }
    } else {
        $error_message = 'Invalid username or password!';
    }
}

// Logout functionality
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User/Admin Login</title>
    <style>
        /* Basic internal CSS for styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 300px;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
            text-align: center;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Login</h2>

    <!-- Display error message if the login fails -->
    <?php if ($error_message): ?>
        <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <!-- Login form -->
    <form action="" method="POST">
        <label for="username">Username</label>
        <input type="text" name="username" id="username" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <input type="submit" name="login" value="Login">
    </form>

    <div class="footer">
        <p>Not registered? <a href="#">Sign up</a></p>
    </div>
</div>

</body>
</html>
