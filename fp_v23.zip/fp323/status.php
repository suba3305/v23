<?php
// Include the database connection
include('db.php');

// Initialize status message variable
$status_message = "";

// Process user input for phone number and get request status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_phone = $_POST['phone'];
    $status_sql = "SELECT * FROM adoption_requests WHERE phone = ?";
    $stmt = $conn->prepare($status_sql);
    $stmt->bind_param("s", $user_phone);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $request = $result->fetch_assoc();
        $status = $request['status'];
        
        if ($status == 'Approved') {
            $status_message = "Congratulations! Your request has been accepted. Your pet will arrive soon.";
        } elseif ($status == 'Rejected') {
            $status_message = "Sorry for the inconvenience, your request has been rejected. Your payment will be refunded soon.";
        } else {
            $status_message = "Your request is still pending. You can cancel your adoption request if you wish.";
        }
    } else {
        $status_message = "No adoption request found with this phone number.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Request Status</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: url('img/h2.jpeg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Glass Effect Container */
        .container {
            background-color: rgba(255, 255, 255, 0.1); /* Semi-transparent white */
            backdrop-filter: blur(10px); /* Glass effect */
            padding: 40px;
            border-radius: 15px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        /* Title Styling */
        h1 {
            font-size: 2rem;
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            font-size: 1rem;
            color: #fff;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            outline: none;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus {
            border-color: #e94e10;
        }

        button[type="submit"] {
            padding: 10px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #27ae60;
        }

        /* Status Message Styling */
        .status-message {
            margin-top: 20px;
            padding: 15px;
            text-align: center;
            font-size: 1.1rem;
            border-radius: 5px;
        }

        .approved {
            background-color: #2ecc71;
            color: white;
        }

        .rejected {
            background-color: #e74c3c;
            color: white;
        }

        .pending {
            background-color: #f39c12;
            color: white;
        }

        .error {
            background-color: #e74c3c;
            color: white;
        }

        /* Button Styling */
        .btn-primary {
            background-color: #2ecc71;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1rem;
        }

        .btn-primary:hover {
            background-color: #27ae60;
        }

        .btn-cancel {
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .btn-cancel:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Check Adoption Request Status</h1>

        <form method="POST" action="">
            <label for="phone">Enter Your Phone Number:</label>
            <input type="text" id="phone" name="phone" placeholder="Your Phone Number" required>
            <button type="submit">Check Status</button>
        </form>

        <!-- Display status message -->
        <?php if (!empty($status_message)): ?>
            <div class="status-message <?php 
                if (strpos($status_message, 'accepted') !== false) {
                    echo 'approved';
                } elseif (strpos($status_message, 'rejected') !== false) {
                    echo 'rejected';
                } elseif (strpos($status_message, 'pending') !== false) {
                    echo 'pending';
                } else {
                    echo 'error';
                }
            ?>">
                <?php echo $status_message; ?>
            </div>
        <?php endif; ?>

        <!-- Cancel Request Button for Pending requests -->
        <?php if (isset($request) && $request['status'] == 'Pending'): ?>
            <div style="text-align: center; margin-top: 20px;">
                <a href="cancel.php?phone=<?php echo urlencode($user_phone); ?>">
                    <button type="button" class="btn-cancel">Cancel Request</button>
                </a>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
