<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Care Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

      /* Navigation Styling */
      nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color:rgb(148, 110, 48);
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Grid Layout for Pet Care Products */
        .container {
            width: 80%;
            margin: 40px auto;
            text-align: center;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .product-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            padding: 20px;
        }

        .product-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
        }

        .product-card h2 {
            margin: 10px 0;
            color: #333;
        }

        .product-card p {
            color: #777;
            padding: 0 15px;
        }

        .price {
            font-size: 20px;
            color: #2d3e50;
            font-weight: bold;
        }

        .buy-button {
            background-color: #2d3e50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .buy-button:hover {
            background-color: #a77628;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav>
    <!-- Logo -->
    <a href="index.php" class="logo">Paw Finder</a>
    
    <!-- Dropdown Menu for Pets List -->
    <div class="dropdown">
        <a href="#">Pets List</a>
        <div class="dropdown-content">
            <a href="dogs.php">Dogs</a>
            <a href="cats.php">Cats</a>
            <a href="other_pets.php">Other Pets</a>
        </div>
    </div>

    <!-- Other Navigation Links -->
    <a href="pet_tips.php">Pet Tips</a>
 
    <a href="adopt_now.php">Adopt Now</a>
    <a href="pet_care.php">Pet Care</a>
    <a href="feedback.php">Feedback</a>
    <a href="login.php">Login</a>
    <a href="admin_login.php">Admin</a>
</nav>

<!-- Pet Care Products Section -->
<div class="container">
    <h1>Shop for Pet Care Products</h1>
    <div class="grid">
        <?php
        // Example products array with real shopping links
        $products = [
            [
                "name" => "Dog Shampoo",
                "image" => "img/sh3.jfif",
                "description" => "Gentle shampoo for your furry friend.",
          
                "link" => "https://www.amazon.in/ZOIVANE-Shampoo-Ditch-Itch-Dandruff/dp/B09SBBN5X6/ref=sr_1_2_sspa?crid=3FRG2WOKJWEI2&dib=eyJ2IjoiMSJ9.V8mYRv4sysKXJUra-6bTxRjYEv_VbdJDznQxQM0p1y_y74L2_X42xP9UucZVfGsD6AVZO5Geg7inML10uCeulEb-ZzhhFjIerJO7Tq64wiLOlxnzLIDbyjweORj-ouQ_IvCwfZkrdDliggUggIijvJb2CeRILkD-z0NkexPjUb6DfEIHS5HmdgMtPLHhWH1WAMR0XAqdEGPJZwR3-acTz6tWaG-A2mIXNd88DeRSYlFdGWtNbYRUgheC6P3C3PCK0wEbBxN5HGE6-OP-WdyDtiqjGQQdQGDK8uJxf7a0INY.h5y6TyM7JUe9u7NPSG0aVXMmEN4BRj67h71KJ4AG-ZA&dib_tag=se&keywords=dog%2Bshampoo&qid=1741748473&sprefix=dog%2Bshamp%2Caps%2C775&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1"// Amazon link for Dog Shampoo
            ],
            [
                "name" => "Cat Litter",
                "image" => "img/cl.png",
                "description" => "Premium quality litter for your cats.",
          
                "link" => "https://www.amazon.in/s?k=cat+litter&ref=nb_sb_noss" // Amazon link for Cat Litter
            ],
            [
                "name" => "Pet Collar",
                "image" => "img/petclr.webp",
                "description" => "Durable collar for your pet's safety.",
                
                "link" => "https://www.amazon.in/s?k=pet+coller&crid=3TKSCF3N9C64E&sprefix=pet+cooler%2Caps%2C389&ref=nb_sb_noss_1" // Amazon link for Pet Collar
            ],
            [
                "name" => "Pet Brush",
                "image" => "img/petb.jfif",
                "description" => "High-quality brush for smooth fur.",
            
                "link" => "https://www.amazon.in/s?k=pet+brush&crid=TO7VAJOQB958&sprefix=pet+brush%2Caps%2C388&ref=nb_sb_noss_1" // Amazon link for Pet Brush
            ],
            [
                "name" => "Pet Food",
                "image" => "img/petf.jpg",
                "description" => "Healthy and nutritious food for your pet.",
              
                "link" => "https://www.amazon.in/s/ref=nb_sb_noss_2?url=search-alias%3Dpets&field-keywords=pet+food&crid=1QL7LGJ28I1I0&sprefix=pet+food%2Cpets%2C471" // Amazon link for Pet Food
            ],
            [
                "name" => "Pet Bed",
                "image" => "img/petbed.jfif",
                "description" => "Comfortable bed for your pet to rest.",
            
                "link" => "https://www.amazon.in/s?k=pet+bed&crid=2TSME36G692WE&sprefix=pet+bed%2Caps%2C375&ref=nb_sb_noss_1" // Amazon link for Pet Bed
            ],
            [
                "name" => "Pet Toy",
                "image" => "img/pettoy.jfif",
                "description" => "Fun toy to keep your pet entertained.",
             
                "link" => "https://www.amazon.in/s?k=pet+toys&crid=1K2I4X2TBI1JI&sprefix=pet+toys%2Caps%2C559&ref=nb_sb_noss_1" // Amazon link for Pet Toy
            ],
            [
                "name" => "Pet Water Bottle",
                "image" => "img/petbtl.jpg",
                "description" => "Portable water bottle for outdoor activities.",
                
                "link" => "https://www.amazon.in/s?k=pet+water+bottel&crid=34UPAVJF1MYE3&sprefix=pet+water+bottel+%2Caps%2C325&ref=nb_sb_noss_2" // Amazon link for Pet Water Bottle
            ],
            [
                "name" => "Pet First Aid Kit",
                "image" => "img/fk.jfif",
                "description" => "Complete first aid kit for emergencies.",
              
                "link" => "https://www.amazon.in/s?k=pet+first+aid+kit&crid=73ANQ0A60D2E&sprefix=pet+first%2Caps%2C330&ref=nb_sb_ss_ts-doa-p_2_9" // Amazon link for Pet First Aid Kit
            ]
        ];

        // Loop through products and display them
        foreach ($products as $product) {
            echo '<div class="product-card">';
            echo '<img src="' . $product['image'] . '" alt="' . $product['name'] . '">';
            echo '<h2>' . $product['name'] . '</h2>';
            echo '<p>' . $product['description'] . '</p>';
    
            echo '<a href="' . $product['link'] . '" target="_blank"><button class="buy-button">Get Link Now</button></a>';
            echo '</div>';
        }
        ?>
    </div>
</div>

</body>
</html>
