<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paw_finder";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$name = $image = $description = $puppy_price = $adult_price = $senior_price = "";
$error_message = "";
$success_message = "";

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the dog's data from the database
    $sql = "SELECT * FROM dogs WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $dog = $result->fetch_assoc();
        $name = $dog['name'];
        $image = $dog['image'];
        $description = $dog['description'];
        $puppy_price = $dog['puppy_price'];
        $adult_price = $dog['adult_price'];
        $senior_price = $dog['senior_price'];
    } else {
        $error_message = "Dog not found.";
    }
} else {
    $error_message = "No dog ID provided.";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from the form
    $name = $_POST['name'];
    $image = $_POST['image'];
    $description = $_POST['description'];
    $puppy_price = $_POST['puppy_price'];
    $adult_price = $_POST['adult_price'];
    $senior_price = $_POST['senior_price'];

    // Check for empty fields
    if (empty($name) || empty($image) || empty($description) || empty($puppy_price) || empty($adult_price) || empty($senior_price)) {
        $error_message = "All fields are required!";
    } else {
        // Update the dog's details in the database
        $update_sql = "UPDATE dogs SET name=?, image=?, description=?, puppy_price=?, adult_price=?, senior_price=? WHERE id=?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("sssiiii", $name, $image, $description, $puppy_price, $adult_price, $senior_price, $id);

        if ($stmt->execute()) {
            $success_message = "Dog details updated successfully.";
        } else {
            $error_message = "Error updating dog details.";
        }

        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dog Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 50%;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(14, 12, 12, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        input, textarea {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #2d3e50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a77628;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            border-radius: 5px;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Edit Dog Details</h1>

        <!-- Display error or success message -->
        <?php if ($error_message != ""): ?>
            <div class="message error"><?php echo $error_message; ?></div>
        <?php elseif ($success_message != ""): ?>
            <div class="message success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <!-- Form to update the dog's details -->
        <form method="POST" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>

            <label for="image">Image URL:</label>
            <input type="text" id="image" name="image" value="<?php echo htmlspecialchars($image); ?>" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($description); ?></textarea>

            <label for="puppy_price">Puppy Price (₹):</label>
            <input type="number" id="puppy_price" name="puppy_price" value="<?php echo htmlspecialchars($puppy_price); ?>" required>

            <label for="adult_price">Adult Price (₹):</label>
            <input type="number" id="adult_price" name="adult_price" value="<?php echo htmlspecialchars($adult_price); ?>" required>

            <label for="senior_price">Senior Price (₹):</label>
            <input type="number" id="senior_price" name="senior_price" value="<?php echo htmlspecialchars($senior_price); ?>" required>

            <button type="submit">Update Dog</button>
        </form>
    </div>

</body>
</html>
