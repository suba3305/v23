<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Buttons</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
            margin: 0;
        }

        .button {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background-color: #007BFF; /* Blue background */
            color: white; /* White text */
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 0 20px;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        .button:active {
            background-color: #004085; /* Even darker on active */
        }
    </style>
</head>
<body>

    <a href="userlogin.php" class="button">User Login</a>
    <a href="adminlogin.php" class="button">Admin Login</a>

</body>
</html>