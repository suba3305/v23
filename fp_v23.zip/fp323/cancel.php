<?php
// Include the database connection
include('db.php');

// Initialize variables
$phone = isset($_GET['phone']) ? $_GET['phone'] : ''; // Get phone number from URL parameter
$message = "";
$current_status = ''; // Initialize $current_status variable

// Check if the phone number is provided and valid
if (!empty($phone)) {
    // Fetch the current status of the adoption request
    $status_query = "SELECT status FROM adoption_requests WHERE phone = ?";
    $stmt = $conn->prepare($status_query);
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($current_status);
        $stmt->fetch();
    } else {
        $message = "No request found for this phone number.";
    }
    $stmt->close();
}

// Process the cancel request if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cancel_reason = $_POST['reason'];

    // Check if the request is in 'Pending' state
    if ($current_status == 'Pending') {
        if (!empty($cancel_reason)) {
            // Update the request status to 'Cancelled' and record the reason
            $update_sql = "UPDATE adoption_requests SET status = 'Cancelled', cancel_reason = ? WHERE phone = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("ss", $cancel_reason, $phone);
            if ($stmt->execute()) {
                $message = "Your request has been successfully cancelled. Thank you for letting us know.";
            } else {
                $message = "There was an issue cancelling your request. Please try again.";
            }
            $stmt->close();
        } else {
            $message = "Please provide a reason for cancelling the request.";
        }
    } else {
        // If the status is not 'Pending', notify the user that cancellation is not allowed
        $message = "You can only cancel requests that are in 'Pending' status.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancel Adoption Request</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: url('img/h2.jpeg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Glass Effect Container */
        .container {
            background-color: rgba(255, 255, 255, 0.1); /* Semi-transparent white */
            backdrop-filter: blur(10px); /* Glass effect */
            padding: 40px;
            border-radius: 15px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        /* Title Styling */
        h1 {
            font-size: 2.2rem;
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            font-size: 1rem;
            color: #fff;
        }

        textarea {
            padding: 12px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            outline: none;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            resize: vertical;
            min-height: 100px;
            transition: border-color 0.3s ease;
        }

        textarea:focus {
            border-color: #e94e10;
        }

        button[type="submit"] {
            padding: 12px;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #c0392b;
        }

        /* Status Message Styling */
        .status-message {
            margin-top: 20px;
            padding: 15px;
            text-align: center;
            font-size: 1.1rem;
            border-radius: 5px;
            background-color: #2ecc71;
            color: white;
        }

        .status-message.error {
            background-color: #e74c3c;
        }

        /* Button for Going Back */
        .btn-back {
            margin-top: 15px;
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .btn-back:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Cancel Adoption Request</h1>

        <!-- Display message if present -->
        <?php if (!empty($message)): ?>
            <div class="status-message <?php echo (strpos($message, 'successfully') !== false) ? '' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Check if the status is 'Pending' before showing the cancellation form -->
        <?php if ($current_status == 'Pending'): ?>
            <!-- Cancellation Form -->
            <form method="POST" action="">
                <label for="reason">Reason for Cancelling:</label>
                <textarea id="reason" name="reason" placeholder="Please provide your reason for cancelling..." required></textarea>

                <button type="submit">Submit Cancellation</button>
            </form>
        <?php else: ?>
            <!-- Display message if the status is not 'Pending' -->
            <div class="status-message">
                You cannot cancel this request as it is either approved or rejected.
            </div>
        <?php endif; ?>

        <!-- Back Button -->
        <a href="index.php">
            <button type="button" class="btn-back">Go Back</button>
        </a>
    </div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
