<?php
// Include the database connection
include('db.php');

// Fetch adoption requests from the database, including cancelled requests
$sql = "SELECT * FROM adoption_requests"; // Replace 'adoption_requests' with your actual table name
$adoption_result = $conn->query($sql);

// Process approval, rejection, and cancellation actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle approval action
    if (isset($_POST['approve_id'])) {
        $approve_id = $_POST['approve_id'];
        $approve_sql = "UPDATE adoption_requests SET status='Approved' WHERE id=?";
        $stmt = $conn->prepare($approve_sql);
        $stmt->bind_param("i", $approve_id);
        $stmt->execute();
        $stmt->close();
    }

    // Handle rejection action
    if (isset($_POST['reject_id'])) {
        $reject_id = $_POST['reject_id'];
        $reject_sql = "UPDATE adoption_requests SET status='Rejected' WHERE id=?";
        $stmt = $conn->prepare($reject_sql);
        $stmt->bind_param("i", $reject_id);
        $stmt->execute();
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Requests Management</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            color: #333;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        /* Navbar Styling */
        nav {
            background-color: #2c3e50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 1.1rem;
            margin-right: 20px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #f39c12;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
        }

        /* Sidebar Styling */
        .container {
            display: flex;
            flex: 1;
        }

        .sidebar {
            background-color: #34495e;
            color: #ecf0f1;
            width: 250px;
            padding-top: 20px;
            height: 100%;
            position: sticky;
            top: 0;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 1.2rem;
            padding: 15px 25px;
            display: block;
            margin: 8px 0;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #f39c12;
        }

        .sidebar a.active {
            background-color: #e67e22;
        }

        /* Main Content Styling */
        .main-content {
            flex: 1;
            padding: 30px;
            background-color: #ecf0f1;
        }

        h1 {
            color: #2c3e50;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #e94e10;
            color: white;
            font-weight: bold;
        }

        td {
            background-color: #f9f9f9;
        }

        tr:nth-child(even) td {
            background-color: #f1f1f1;
        }

        tr:hover {
            background-color: #f0f0f0;
        }

        .no-requests {
            text-align: center;
            font-size: 18px;
            color: #777;
        }

        /* Button Spacing */
        .action-buttons {
            display: flex;
            gap: 15px; /* Adds space between the buttons */
        }

        /* Selected Button */
        .selected {
            background-color: #27ae60;
            color: white;
        }

        /* Red color for the rejected button when selected */
        .reject-btn.selected {
            background-color: #e74c3c; /* Red color for selected reject */
            color: white;
        }

        .approve-btn.selected {
            background-color: #2ecc71;
            color: white;
        }

        /* Footer Styling */
        .footer {
            background-color: #2c3e50;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                padding-top: 10px;
            }

            .sidebar a {
                font-size: 1rem;
                padding: 12px 20px;
            }

            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <div class="navbar-brand">Paw Finder Admin</div>
        <div>
            <a href="logout.php">Logout</a>
        </div>
    </nav>

    <!-- Main Content Section -->
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="update_dogs.php">Update Dogs</a>
            <a href="update_cats.php">Update Cats</a>
            <a href="update_other.php">Update Pets</a>
            <a href="view_dogs.php">View Dogs</a>
            <a href="view_cats.php">View Cats</a>
            <a href="view_other.php">View Pets</a>
            <a href="view_adoptionreq.php" class="active">View Adoption Requests</a>
            <a href="view_feedbacks.php">User Feedbacks</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>Adoption Requests</h1>
            <p>Below is the list of adoption requests submitted by users. Please review and take action as necessary.</p>

            <!-- Adoption Requests Table -->
            <?php if ($adoption_result && $adoption_result->num_rows > 0) { ?>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>Pet Type</th>
                        <th>Pet Name</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Reason</th>
                        <th>Submission Date</th>
                        <th>Status</th>
                        <th>Cancel Reason</th>
                        <th>Actions</th>
                    </tr>
                    <?php while ($request = $adoption_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['id']); ?></td>
                            <td><?php echo htmlspecialchars($request['pet_type']); ?></td>
                            <td><?php echo htmlspecialchars($request['pet_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['email']); ?></td>
                            <td><?php echo htmlspecialchars($request['phone']); ?></td>
                            <td><?php echo htmlspecialchars($request['address']); ?></td>
                            <td><?php echo htmlspecialchars($request['reason']); ?></td>
                            <td><?php echo htmlspecialchars($request['submission_date']); ?></td>
                            <td><?php echo htmlspecialchars($request['status']); ?></td>
                            <td>
                                <?php echo $request['status'] == 'Cancelled' ? htmlspecialchars($request['cancel_reason']) : 'N/A'; ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <?php if ($request['status'] == 'Pending') { ?>
                                        <form action="" method="POST">
                                            <button type="submit" name="approve_id" value="<?php echo $request['id']; ?>" 
                                                    class="approve-btn <?php echo ($request['status'] == 'Approved') ? 'selected' : ''; ?>">Approve</button>
                                        </form>
                                        <form action="" method="POST">
                                            <button type="submit" name="reject_id" value="<?php echo $request['id']; ?>" 
                                                    class="reject-btn <?php echo ($request['status'] == 'Rejected') ? 'selected' : ''; ?>">Reject</button>
                                        </form>
                                    <?php } else { ?>
                                        <!-- Disable buttons for cancelled, approved, or rejected requests -->
                                        <button type="button" class="approve-btn" disabled>Approve</button>
                                        <button type="button" class="reject-btn" disabled>Reject</button>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            <?php } else { ?>
                <p class="no-requests">No adoption requests found.</p>
            <?php } ?>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 Paw Finder. All Rights Reserved.</p>
    </div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
