<?php
// Database connection
$servername = "localhost";
$username = "root";  // replace with your database username
$password = "";      // replace with your database password
$dbname = "paw_finder";  // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT * FROM other_pets";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $other_pets = [];
    while($row = $result->fetch_assoc()) {
        $other_pets[] = $row;
    }
} else {
    $other_pets = [];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Other Pets Adoption</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Navigation Styling */
        nav {
            background-color: #2d3e50;
            padding: 16px 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #a77628;
        }

        /* Logo Styling */
        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Dropdown Menu Styling */
        .dropdown {
            display: inline-block;
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #2d3e50;
            min-width: 160px;
            z-index: 1;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .dropdown-content a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #f39c12;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns */
            gap: 20px;
            margin-top: 20px;
        }

        .pet-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .pet-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .pet-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .pet-card h2 {
            margin: 10px 0;
            color: #555;
        }

        .pet-card p {
            color: #777;
            padding: 0 15px;
        }

        .pet-card .price {
            color: #333;
            font-size: 18px;
            margin: 10px 0;
        }

        .adopt-button {
            background-color: rgb(1, 20, 1);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 15px;
        }

        .adopt-button:hover {
            background-color: rgb(230, 114, 6);
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <!-- Logo -->
        <a href="index.php" class="logo">Paw Finder</a>
        
        <!-- Dropdown Menu for Pets List -->
        <div class="dropdown">
            <a href="#">Pets List</a>
            <div class="dropdown-content">
                <a href="dogs.php">Dogs</a>
                <a href="cats.php">Cats</a>
                <a href="other_pets.php">Other Pets</a>
            </div>
        </div>

        <!-- Other Navigation Links -->
        <a href="pet_tips.php">Pet Tips</a>
       
        <a href="adopt_now.php">Adopt Now</a>
        <a href="pet_care.php">Pet Care</a>
        <a href="feedback.php">Feedback</a>
        <a href="login.php">Login</a>
        <a href="admin_login.php">Admin</a>
    </nav>

    <div class="container">
        <h1>Adopt an Other Pet Today!</h1>
        <div class="grid">
            <?php
            foreach ($other_pets as $pet) {
                echo '<div class="pet-card">';
                echo '<img src="' . $pet['image'] . '" alt="' . $pet['name'] . '">';
                echo '<h2>' . $pet['name'] . '</h2>';
                echo '<p>' . $pet['description'] . '</p>';
                echo '<p class="price">Price: ₹' . $pet['price'] . '</p>';
                echo '<a href="login.php"><button class="adopt-button">Adopt Now</button></a>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
